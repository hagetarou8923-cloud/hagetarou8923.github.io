(() => {
  'use strict';

  window.NYANKO_VIP_ACTIVE = false;
  const modal = document.getElementById('vip-modal');
  if (!modal) return;

  const $ = (id) => document.getElementById(id);
  const userView = $('vip-user-view');
  const loginView = $('vip-admin-login-view');
  const adminView = $('vip-admin-view');
  const msg = $('vip-main-message');
  let state = null;
  let csrfToken = '';

  const statusLabels = {
    pending: '申請受付・確認待ち',
    approved: '承認済み・VIP付与済み',
    rejected: '申請却下'
  };

  function setMessage(target, text, kind = '') {
    target.textContent = text || '';
    target.className = `vip-msg${kind ? ` ${kind}` : ''}`;
  }

  function formatDate(epoch) {
    if (!epoch) return '—';
    const date = new Date(Number(epoch) * 1000);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString('ja-JP');
  }

  function yen(value) {
    return `¥${Number(value || 0).toLocaleString('ja-JP')}`;
  }

  function api(path, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
    if (csrfToken) headers.set('X-CSRF-Token', csrfToken);
    return fetch(path, { ...options, headers, credentials: 'same-origin', cache: 'no-store' })
      .then(async (response) => {
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
        return data;
      });
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  async function refreshStatus() {
    state = await api('/api/vip/status');
    csrfToken = state.csrf_token || '';
    window.NYANKO_VIP_ACTIVE = !!state.is_vip;
    applyVipLocks();
    const badge = $('vip-header-status');
    if (badge) {
      badge.textContent = state.is_vip ? 'VIP 有効' : 'FREE';
      badge.classList.toggle('active', !!state.is_vip);
      badge.title = state.is_vip ? `有効期限：${formatDate(state.expires_at)}` : 'VIP未契約';
    }
    return state;
  }

  const vipSystemActions = new Set([
    'user_rank_rewards_claimed', 'user_rank_rewards_unclaimed',
    'catguide_rewards_claimed', 'catguide_rewards_unclaimed',
    'cat_scratcher_reset', 'all_missions_clear', 'labyrinth_medals',
    'ototo_detailed', 'dojo_score_detailed', 'future_score_detailed'
  ]);
  const vipCharacterActions = new Set(['talents_specific', 'talents_disable_all', 'lineup_custom']);

  function isVipLockedOption(node) {
    const value = node?.dataset?.v;
    const group = node?.dataset?.optionGroup;
    return !window.NYANKO_VIP_ACTIVE &&
      ((group === 's2' && vipSystemActions.has(value)) ||
       (group === 's3' && vipCharacterActions.has(value)));
  }

  const vipDetailCardSelector = [
    '[id^="vip-item-"]', '[id^="talent-orb-"]', '[id^="event-ticket-"]',
    '[id^="facility-"]', '[id^="legend-card-"]', '[id^="special-stage-card-"]',
    '[id^="main-story-chapters-card-"]', '[id^="event-stage-card-"]',
    '[id^="labyrinth-medal-card-"]', '[id^="ototo-card-"]',
    '[id^="dojo-score-card-"]', '[id^="future-score-card-"]',
    '[id^="lineup-card-"]'
  ].join(',');

  function applyVipLocks() {
    document.querySelectorAll('[data-option-group][data-v]').forEach((node) => {
      const locked = isVipLockedOption(node);
      node.classList.toggle('vip-locked-control', locked);
      if (locked) node.title = 'VIP限定機能です。VIP申請後、管理者の承認で利用できます。';
      else if (node.title.includes('VIP限定機能')) node.removeAttribute('title');
    });

    document.querySelectorAll(vipDetailCardSelector).forEach((card) => {
      const locked = !window.NYANKO_VIP_ACTIVE;
      card.classList.toggle('vip-locked-card', locked);
      let note = card.querySelector(':scope > .vip-lock-note');
      if (locked && !note) {
        note = el('div', 'vip-lock-note', 'VIP限定設定です。VIP申請後、管理者の承認で利用できます。');
        card.insertBefore(note, card.children[1] || null);
      } else if (!locked && note) {
        note.remove();
      }
    });
  }

  const vipLockObserver = new MutationObserver(applyVipLocks);
  vipLockObserver.observe(document.body, { childList: true, subtree: true });

  function renderUser() {
    if (!state) return;
    $('vip-user-state').textContent = state.is_vip
      ? `VIP契約中（有効期限：${formatDate(state.expires_at)}）`
      : 'FREE（VIP未契約）';
    $('vip-user-id').textContent = state.visitor_id;
    $('vip-user-id-copy').onclick = async () => {
      try {
        await navigator.clipboard.writeText(state.visitor_id);
        $('vip-user-id-copy').textContent = 'コピー済み';
        setTimeout(() => { $('vip-user-id-copy').textContent = 'コピー'; }, 1300);
      } catch {
        setMessage(msg, '利用IDを選択してコピーしてください。', 'error');
      }
    };

    const select = $('vip-plan-days');
    const previous = select.value;
    select.replaceChildren();
    (state.plans || []).forEach((plan) => {
      const option = document.createElement('option');
      option.value = String(plan.days);
      option.textContent = `${plan.days}日プラン — ${yen(plan.price_yen)}`;
      select.appendChild(option);
    });
    if ([...select.options].some((option) => option.value === previous)) select.value = previous;
    const updatePrice = () => {
      const plan = (state.plans || []).find((item) => String(item.days) === select.value);
      $('vip-plan-price').textContent = plan ? `申請金額：${yen(plan.price_yen)}` : '';
    };
    select.onchange = updatePrice;
    updatePrice();

    const requestsRoot = $('vip-user-requests');
    requestsRoot.replaceChildren();
    const requests = state.requests || [];
    if (!requests.length) {
      requestsRoot.appendChild(el('p', 'vip-muted', '申請履歴はありません。'));
    } else {
      requests.forEach((item) => {
        const record = el('div', 'vip-record');
        const top = el('div', 'vip-record-top');
        top.appendChild(el('strong', '', `${item.reference_code}　VIP ${item.plan_days}日`));
        const pill = el('span', `vip-pill ${item.status}`, statusLabels[item.status] || item.status);
        top.appendChild(pill);
        record.append(top, el('p', 'vip-muted', `${yen(item.price_yen)} ・ ${formatDate(item.created_at)}`));
        if (item.admin_note) record.appendChild(el('p', 'vip-muted', `管理者メモ：${item.admin_note}`));
        requestsRoot.appendChild(record);
      });
    }
    const pending = requests.some((item) => item.status === 'pending');
    $('vip-request-submit').disabled = pending;
    $('vip-request-submit').textContent = pending ? '確認待ちの申請があります' : 'VIP購入を申請する';
    $('vip-payment-note').textContent = pending
      ? '現在、確認待ちの申請があります。管理者の対応後に新しい申請ができます。'
      : '申請後、管理者が支払いを確認してから承認・VIP付与を行います。画面上で自動決済は行われません。';
  }

  function renderAdmin(data) {
    $('vip-admin-summary').replaceChildren();
    [
      ['対応待ち申請', data.summary?.pending ?? 0],
      ['VIP有効', data.summary?.active_vip ?? 0],
      ['申請総数', data.summary?.total_requests ?? 0]
    ].forEach(([label, value]) => {
      const box = el('div', 'vip-stat');
      box.append(el('span', '', label), el('strong', '', String(value)));
      $('vip-admin-summary').appendChild(box);
    });

    const ticketsRoot = $('vip-admin-requests');
    ticketsRoot.replaceChildren();
    const requests = data.requests || [];
    if (!requests.length) ticketsRoot.appendChild(el('p', 'vip-muted', '購入申請はありません。'));
    requests.forEach((item) => {
      const card = el('article', 'vip-admin-ticket');
      const title = el('div', 'vip-record-top');
      title.append(
        el('strong', '', `${item.display_name}　／　${item.reference_code}`),
        el('span', `vip-pill ${item.status}`, statusLabels[item.status] || item.status)
      );
      card.append(title);
      card.appendChild(el('p', '', `VIP ${item.plan_days}日 ・ ${yen(item.price_yen)} ・ ${formatDate(item.created_at)}`));
      card.appendChild(el('p', '', `利用ID：${item.visitor_id}`));
      if (item.contact) card.appendChild(el('p', '', `連絡先：${item.contact}`));
      if (item.message) card.appendChild(el('p', '', `申請メモ：${item.message}`));
      if (item.admin_note) card.appendChild(el('p', '', `管理メモ：${item.admin_note}`));
      if (item.status === 'pending') {
        const note = el('textarea');
        note.maxLength = 500;
        note.placeholder = '管理メモ（任意）';
        const actions = el('div', 'vip-actions');
        const approve = el('button', 'vip-btn success', '承認してVIP付与');
        const reject = el('button', 'vip-btn danger', '却下');
        approve.type = reject.type = 'button';
        approve.addEventListener('click', () => decide(item.request_id, 'approved', note.value, approve));
        reject.addEventListener('click', () => decide(item.request_id, 'rejected', note.value, reject));
        actions.append(approve, reject);
        card.append(note, actions);
      }
      ticketsRoot.appendChild(card);
    });

    const membersRoot = $('vip-admin-members');
    membersRoot.replaceChildren();
    const members = data.members || [];
    if (!members.length) membersRoot.appendChild(el('p', 'vip-muted', 'VIP契約者はいません。'));
    members.forEach((member) => {
      const row = el('div', 'vip-member');
      const idBox = document.createElement('div');
      idBox.append(
        el('strong', '', member.display_name || '利用者'),
        el('code', '', member.visitor_id)
      );
      const expiry = el('div', 'vip-expiry', member.revoked_at
        ? `停止済み：${formatDate(member.revoked_at)}`
        : Number(member.expires_at) > Date.now() / 1000
          ? `期限：${formatDate(member.expires_at)}`
          : `期限切れ：${formatDate(member.expires_at)}`);
      row.append(idBox, expiry);
      const actionCell = el('div', 'vip-actions-cell');
      if (!member.revoked_at && Number(member.expires_at) > Date.now() / 1000) {
        const revoke = el('button', 'vip-btn danger', 'VIP停止');
        revoke.type = 'button';
        revoke.addEventListener('click', () => revokeVip(member.visitor_id, revoke));
        actionCell.appendChild(revoke);
      }
      row.appendChild(actionCell);
      membersRoot.appendChild(row);
    });
  }

  async function loadAdmin() {
    setMessage($('vip-admin-message'), '管理情報を読み込んでいます…');
    try {
      const data = await api('/api/legacy-vip/admin/state');
      renderAdmin(data);
      setMessage($('vip-admin-message'), `最終更新：${new Date().toLocaleTimeString('ja-JP')}`, 'ok');
    } catch (error) {
      setMessage($('vip-admin-message'), error.message, 'error');
    }
  }

  async function decide(requestId, status, adminNote, button) {
    const question = status === 'approved'
      ? '支払い確認済みとして承認し、この利用者へVIPを付与しますか？'
      : 'この購入申請を却下しますか？';
    if (!window.confirm(question)) return;
    button.disabled = true;
    try {
      await api(`/api/admin/vip/requests/${encodeURIComponent(requestId)}/decision`, {
        method: 'POST',
        body: JSON.stringify({ status, admin_note: adminNote || '' })
      });
      await loadAdmin();
      await refreshStatus();
      setMessage($('vip-admin-message'), status === 'approved' ? '承認し、VIPを付与しました。' : '申請を却下しました。', 'ok');
    } catch (error) {
      setMessage($('vip-admin-message'), error.message, 'error');
      button.disabled = false;
    }
  }

  async function revokeVip(visitorId, button) {
    if (!window.confirm('この利用者のVIPを停止しますか？')) return;
    button.disabled = true;
    try {
      await api('/api/legacy-vip/admin/revoke', {
        method: 'POST',
        body: JSON.stringify({ visitor_id: visitorId })
      });
      await loadAdmin();
      setMessage($('vip-admin-message'), 'VIPを停止しました。', 'ok');
    } catch (error) {
      setMessage($('vip-admin-message'), error.message, 'error');
      button.disabled = false;
    }
  }

  async function openModal(view) {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    setMessage(msg, '');
    try {
      await refreshStatus();
      if (view === 'admin') {
        userView.hidden = true;
        loginView.hidden = !!state.is_admin;
        adminView.hidden = !state.is_admin;
        if (state.is_admin) await loadAdmin();
        else $('vip-admin-password').focus();
      } else {
        userView.hidden = false;
        loginView.hidden = true;
        adminView.hidden = true;
        renderUser();
      }
    } catch (error) {
      setMessage(msg, error.message, 'error');
      userView.hidden = view !== 'user';
      loginView.hidden = view !== 'admin';
      adminView.hidden = true;
    }
  }

  function closeModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
  }

  window.openNyankoVipPurchase = () => openModal('user');
  window.openNyankoVipAdmin = () => openModal('admin');

  $('vip-request-open').addEventListener('click', () => openModal('user'));
  $('admin-panel-open').addEventListener('click', () => openModal('admin'));
  $('vip-modal-close').addEventListener('click', closeModal);
  modal.addEventListener('click', (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); });

  $('vip-request-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    setMessage(msg, '');
    const button = $('vip-request-submit');
    button.disabled = true;
    try {
      const data = await api('/api/vip/request', {
        method: 'POST',
        body: JSON.stringify({
          plan_days: Number($('vip-plan-days').value),
          display_name: $('vip-display-name').value.trim(),
          contact: $('vip-contact').value.trim(),
          message: $('vip-message').value.trim()
        })
      });
      $('vip-request-form').reset();
      await refreshStatus();
      renderUser();
      setMessage(msg, `申請を受け付けました。受付番号：${data.reference_code}`, 'ok');
    } catch (error) {
      setMessage(msg, error.message, 'error');
    } finally {
      button.disabled = false;
      if (state?.requests?.some((item) => item.status === 'pending')) button.disabled = true;
    }
  });

  $('vip-admin-login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('vip-admin-login-submit');
    button.disabled = true;
    try {
      await api('/api/admin/login', {
        method: 'POST',
        body: JSON.stringify({ password: $('vip-admin-password').value })
      });
      $('vip-admin-password').value = '';
      await refreshStatus();
      loginView.hidden = true;
      adminView.hidden = false;
      await loadAdmin();
    } catch (error) {
      setMessage($('vip-login-message'), error.message, 'error');
    } finally {
      button.disabled = false;
    }
  });

  $('vip-admin-refresh').addEventListener('click', loadAdmin);
  $('vip-admin-logout').addEventListener('click', async () => {
    try {
      await api('/api/admin/logout', { method: 'POST', body: '{}' });
      await refreshStatus();
      adminView.hidden = true;
      loginView.hidden = false;
      $('vip-admin-password').focus();
    } catch (error) {
      setMessage($('vip-admin-message'), error.message, 'error');
    }
  });

  $('vip-manual-grant-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('vip-manual-grant-submit');
    button.disabled = true;
    try {
      await api('/api/legacy-vip/admin/grant', {
        method: 'POST',
        body: JSON.stringify({
          visitor_id: $('vip-manual-visitor-id').value.trim(),
          days: Number($('vip-manual-days').value)
        })
      });
      $('vip-manual-grant-form').reset();
      await loadAdmin();
      setMessage($('vip-admin-message'), 'VIPを付与しました。', 'ok');
    } catch (error) {
      setMessage($('vip-admin-message'), error.message, 'error');
    } finally {
      button.disabled = false;
    }
  });

  // Prime the status badge without opening a modal.
  refreshStatus().catch(() => {
    const badge = $('vip-header-status');
    if (badge) badge.textContent = 'VIP状態未確認';
  });
  if (new URLSearchParams(location.search).get('admin') === '1') {
    setTimeout(() => openModal('admin'), 0);
  }
})();
