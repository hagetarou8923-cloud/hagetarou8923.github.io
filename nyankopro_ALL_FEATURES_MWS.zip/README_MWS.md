# NyankoPro × AUTOCAT JP 統合版 — MWS セットアップ

## この版について

このZIPは `nyankopro` をベースに、`AUTOCAT JP v25` のWeb機能をできるだけ統合した版です。**ゲームデータの代行処理（引き継ぎ・新規作成・複製）と復旧処理は nyankopro の実装を維持**し、AUTOCAT側の代行ワーカー／代行通信フローは移植していません。

統合した主な機能：
- サイト会員登録・ログイン・ログアウト、アカウントダッシュボード
- Discord OAuthログインとDiscord管理者判定
- VIP案内、会員向けVIP購入申請DM、支払いリンク／支払い報告、VIP管理
- 旧nyankoproのブラウザID式VIP申請・管理者パネルも併存
- VIP専用項目のサーバー側制御
- 無料利用回数・招待リンク／招待報酬・VIPお試し利用管理
- チャット、ダイレクトメッセージ、チャット管理・モデレーション
- Discord通知／利用ログ、Web Push通知（VAPID鍵を設定した場合）
- 管理者パネル、アカウント停止・BAN等の会員管理

※ 決済ゲートウェイによる自動入金確認は含みません。支払い内容を確認してから管理者がVIPを付与する方式です。

## MWSへの配置

1. ZIPをMWSのWebサイト用Pythonプロジェクトへ展開します。
2. **`.env` は `main.py` / `main13.py` と同じ階層**に置きます。このZIPには値が空の `.env` を同梱しています。
3. `.env` を編集し、必要な秘密値・URL・Discord設定を入力します。
4. MWSの起動ファイルを `main.py` に設定します（`mws.config` / `Procfile` も同梱）。
5. `requirements.txt` の依存パッケージをインストールして起動します。

このアプリは `main13.py` の先頭で `python-dotenv` の `load_dotenv(<アプリの場所>/.env, override=True)` を実行します。**MWSのWeb環境変数設定は不要**です。MWSのBOT設定欄とWebサイトの設定欄は連動しません。Web側の値はこの `.env` に記入してください。

MWSが再起動時にソースフォルダを初期化する構成の場合、`.env` を毎回消えない永続領域に保存し、起動フォルダから読み込めるようにしてください。`.env` を公開URLやGit等へ公開しないでください。

## `.env` で最初に設定する項目

- `FLASK_SECRET_KEY`：長いランダム値。空欄の場合は `BACKUP/flask_secret.key` を作成して使用します。
- `ADMIN_PANEL_PASSWORD`：旧nyankopro管理者パネルのパスワード。24文字以上のランダム値を推奨。
- `ADMIN_RECOVERY_KEY` / `ADMIN_SNAPSHOT_KEY`：代行復旧API／復旧スナップショット用の秘密値。管理者パスワードとは別に設定。
- `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET`：Discord OAuthアプリの値。
- `DISCORD_REDIRECT_URI`：`https://あなたのMWSドメイン/auth/callback`。Discord Developer Portal側のRedirect URIにも同じ値を登録。
- `PUBLIC_BASE_URL`：MWSで公開するサイトのURL。
- `ADMIN_USER`：管理者にするDiscordユーザーID。複数設定する場合はカンマ区切りで `CHAT_ADMIN_DISCORD_IDS` にも登録。
- `CHAT_ADMIN_DISCORD_IDS`：管理者チャット／モデレーションを許可するDiscordユーザーIDをカンマ区切りで指定。

Discord OAuth・Discord通知・Web Pushを使用しない場合、該当する設定は空欄のままでも起動できます。ただし、それらの機能は設定が完了するまで利用できません。

## .envの例

```dotenv
FLASK_SECRET_KEY=十分に長いランダムな秘密値
ADMIN_PANEL_PASSWORD=別の十分に長い管理者パスワード
ADMIN_RECOVERY_KEY=別の復旧APIキー
ADMIN_SNAPSHOT_KEY=別のスナップショット暗号化キー
DISCORD_CLIENT_ID=DiscordアプリのClient ID
DISCORD_CLIENT_SECRET=DiscordアプリのClient Secret
DISCORD_REDIRECT_URI=https://example.com/auth/callback
PUBLIC_BASE_URL=https://example.com
ADMIN_USER=123456789012345678
CHAT_ADMIN_DISCORD_IDS=123456789012345678
```

実値を設定した `.env` は漏洩させないでください。上記は形式例で、値は必ず自分の環境のものに置き換えてください。

## 価格・VIP

`VIP_PRICE_30` / `VIP_PRICE_60` / `VIP_PRICE_90` で30日・60日・90日の表示価格（円）を変更できます。`VIP_PAYMENT_GUIDE` で購入画面の支払い案内文を設定できます。旧nyankoproのブラウザVIPとAUTOCATの会員アカウントVIPは別々の申請・管理経路を持ちますが、代行側のVIP限定設定は両方のVIP状態を確認します。

## 保存データと更新時の注意

次のファイル／フォルダは実行中に作成されます。MWSの永続ストレージに保持してください。

- `jobs.db`：nyankoproの代行ジョブ状態
- `BACKUP/`：代行復旧データ、セッション鍵
- `vip.db`：nyankopro旧ブラウザVIP申請・契約
- `ACCOUNT/account.db`：サイト会員・VIP・購入DM
- `CHAT/chat.db`：チャット・DM
- `count.db`、`Login/`、`invitation/`：利用回数・招待関連データ（機能で作成）

**既存環境を更新する場合、これらのDB／フォルダと `.env` を削除・初期化しないでください。** 今回のZIPには個人情報・会員データ・発行済み引き継ぎコード・秘密鍵を含む既存DBやバックアップは含めていません。

## 代行処理を維持する範囲

引き継ぎコード取得、セーブデータ編集、最終コード発行、ジョブ管理、管理復旧の中核はnyankoproの実装を維持しています。AUTOCAT側の代行ワーカー／通信フローには置き換えていません。VIP判定や無料利用枠の受付判定など、代行を開始する前のアクセス管理のみ統合しています。

## 動作確認

配布前にPythonソースの構文チェック、Flaskアプリの起動・ルート登録、基本APIのローカル確認を行ってください。実際のMWS環境・Discord OAuth・Discord BOT・PayPay等の外部サービス接続は、利用者自身の`.env`設定とMWS上での確認が必要です。
