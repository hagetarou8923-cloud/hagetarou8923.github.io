"""MWS entry point for the NyankoPro + AUTOCAT integrated Flask application."""
import os
from main13 import app

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "1142"))
    app.run(host="0.0.0.0", port=port, threaded=True, debug=False)
