"""
NyankoPro VIP entitlement and purchase-request subsystem.

This module is intentionally separate from the delegation workers in main13.py.
It only manages browser identities, VIP terms, purchase requests and the admin UI API.
"""
from __future__ import annotations

import functools
import hmac
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import timedelta

from flask import jsonify, request, session


VISITOR_ID_RE = re.compile(r"^[0-9a-f]{32}$")
ALLOWED_PLANS = (30, 60, 90)
REQUEST_STATUSES = {"pending", "approved", "rejected"}


def _positive_price(env_name: str, default: int) -> int:
    try:
        value = int(os.getenv(env_name, str(default)).strip())
        return max(0, min(value, 10_000_000))
    except (TypeError, ValueError):
        return default


class VipStore:
    def __init__(self, database_path: str):
        self.database_path = database_path
        os.makedirs(os.path.dirname(database_path), exist_ok=True)
        self.plans = [
            {"days": 30, "price_yen": _positive_price("VIP_PRICE_30", 300)},
            {"days": 60, "price_yen": _positive_price("VIP_PRICE_60", 600)},
            {"days": 90, "price_yen": _positive_price("VIP_PRICE_90", 900)},
        ]
        self._init_db()

    def connect(self):
        conn = sqlite3.connect(self.database_path, timeout=20)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=20000")
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    @contextmanager
    def connection(self):
        conn = self.connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        with self.connection() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS vip_members (
                    visitor_id TEXT PRIMARY KEY,
                    expires_at REAL NOT NULL,
                    granted_by TEXT NOT NULL DEFAULT 'admin',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    revoked_at REAL
                );

                CREATE TABLE IF NOT EXISTS vip_purchase_requests (
                    request_id TEXT PRIMARY KEY,
                    reference_code TEXT NOT NULL UNIQUE,
                    visitor_id TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    contact TEXT NOT NULL DEFAULT '',
                    plan_days INTEGER NOT NULL,
                    price_yen INTEGER NOT NULL,
                    message TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'pending',
                    admin_note TEXT NOT NULL DEFAULT '',
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    handled_at REAL
                );

                CREATE INDEX IF NOT EXISTS idx_vip_requests_visitor
                    ON vip_purchase_requests(visitor_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_vip_requests_status
                    ON vip_purchase_requests(status, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_vip_members_expiry
                    ON vip_members(expires_at, revoked_at);
                """
            )

    def member(self, visitor_id: str):
        now = time.time()
        with self.connection() as conn:
            row = conn.execute(
                """SELECT visitor_id, expires_at, granted_by, created_at, updated_at, revoked_at
                   FROM vip_members WHERE visitor_id=?""",
                (visitor_id,),
            ).fetchone()
        if not row:
            return None
        data = dict(row)
        data["is_vip"] = data["revoked_at"] is None and float(data["expires_at"]) > now
        return data

    def is_vip(self, visitor_id: str | None = None) -> bool:
        # Routes may call this without an explicit identifier: use the signed
        # browser session established by /api/vip/status.
        if visitor_id is None:
            visitor_id = session.get("nyanko_vip_visitor_id")
        if not isinstance(visitor_id, str) or not VISITOR_ID_RE.fullmatch(visitor_id):
            return False
        member = self.member(visitor_id)
        return bool(member and member["is_vip"])

    def user_requests(self, visitor_id: str, limit: int = 10):
        with self.connection() as conn:
            rows = conn.execute(
                """SELECT request_id, reference_code, display_name, contact, plan_days,
                          price_yen, message, status, admin_note, created_at, updated_at, handled_at
                   FROM vip_purchase_requests
                   WHERE visitor_id=? ORDER BY created_at DESC LIMIT ?""",
                (visitor_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def create_request(self, visitor_id: str, payload: dict):
        now = time.time()
        days = int(payload["plan_days"])
        price = next(plan["price_yen"] for plan in self.plans if plan["days"] == days)
        request_id = uuid.uuid4().hex
        reference = secrets.token_hex(4).upper()
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            pending = conn.execute(
                "SELECT reference_code FROM vip_purchase_requests WHERE visitor_id=? AND status='pending' LIMIT 1",
                (visitor_id,),
            ).fetchone()
            if pending:
                conn.rollback()
                return None, str(pending["reference_code"])
            conn.execute(
                """INSERT INTO vip_purchase_requests
                   (request_id, reference_code, visitor_id, display_name, contact,
                    plan_days, price_yen, message, status, created_at, updated_at)
                   VALUES(?,?,?,?,?,?,?,?, 'pending', ?, ?)""",
                (
                    request_id, reference, visitor_id, payload["display_name"],
                    payload["contact"], days, price, payload["message"], now, now,
                ),
            )
            conn.commit()
        return request_id, reference

    def _grant_in_transaction(self, conn, visitor_id: str, days: int, admin_id: str, now: float):
        row = conn.execute(
            "SELECT expires_at, revoked_at, created_at FROM vip_members WHERE visitor_id=?",
            (visitor_id,),
        ).fetchone()
        if row and row["revoked_at"] is None and float(row["expires_at"]) > now:
            base = float(row["expires_at"])
            created_at = float(row["created_at"])
        else:
            base = now
            created_at = now
        expires_at = base + days * 86400
        conn.execute(
            """INSERT INTO vip_members(visitor_id, expires_at, granted_by, created_at, updated_at, revoked_at)
               VALUES(?,?,?,?,?,NULL)
               ON CONFLICT(visitor_id) DO UPDATE SET
                   expires_at=excluded.expires_at,
                   granted_by=excluded.granted_by,
                   updated_at=excluded.updated_at,
                   revoked_at=NULL""",
            (visitor_id, expires_at, admin_id, created_at, now),
        )
        return expires_at

    def decide_request(self, request_id: str, status: str, admin_note: str, admin_id: str):
        now = time.time()
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                "SELECT * FROM vip_purchase_requests WHERE request_id=?",
                (request_id,),
            ).fetchone()
            if not row:
                conn.rollback()
                return None, "not_found"
            if row["status"] != "pending":
                conn.rollback()
                return None, "already_handled"
            expires_at = None
            if status == "approved":
                expires_at = self._grant_in_transaction(
                    conn, str(row["visitor_id"]), int(row["plan_days"]), admin_id, now
                )
            conn.execute(
                """UPDATE vip_purchase_requests
                   SET status=?, admin_note=?, updated_at=?, handled_at=?
                   WHERE request_id=? AND status='pending'""",
                (status, admin_note, now, now, request_id),
            )
            conn.commit()
        return expires_at, None

    def manual_grant(self, visitor_id: str, days: int, admin_id: str):
        now = time.time()
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            expires_at = self._grant_in_transaction(conn, visitor_id, days, admin_id, now)
            conn.commit()
        return expires_at

    def revoke(self, visitor_id: str):
        now = time.time()
        with self.connection() as conn:
            cur = conn.execute(
                """UPDATE vip_members SET revoked_at=?, updated_at=?
                   WHERE visitor_id=? AND revoked_at IS NULL""",
                (now, now, visitor_id),
            )
            return cur.rowcount == 1

    def admin_state(self):
        with self.connection() as conn:
            requests_rows = conn.execute(
                """SELECT request_id, reference_code, visitor_id, display_name, contact,
                          plan_days, price_yen, message, status, admin_note, created_at,
                          updated_at, handled_at
                   FROM vip_purchase_requests
                   ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, created_at DESC
                   LIMIT 300"""
            ).fetchall()
            members_rows = conn.execute(
                """SELECT m.visitor_id, m.expires_at, m.granted_by, m.created_at,
                          m.updated_at, m.revoked_at,
                          (SELECT r.display_name FROM vip_purchase_requests r
                           WHERE r.visitor_id=m.visitor_id ORDER BY r.created_at DESC LIMIT 1) AS display_name,
                          (SELECT r.contact FROM vip_purchase_requests r
                           WHERE r.visitor_id=m.visitor_id ORDER BY r.created_at DESC LIMIT 1) AS contact
                   FROM vip_members m
                   ORDER BY m.expires_at DESC LIMIT 300"""
            ).fetchall()
            pending = conn.execute(
                "SELECT COUNT(*) FROM vip_purchase_requests WHERE status='pending'"
            ).fetchone()[0]
            total_requests = conn.execute(
                "SELECT COUNT(*) FROM vip_purchase_requests"
            ).fetchone()[0]
            now = time.time()
            active = conn.execute(
                "SELECT COUNT(*) FROM vip_members WHERE revoked_at IS NULL AND expires_at>?",
                (now,),
            ).fetchone()[0]
        return {
            "requests": [dict(row) for row in requests_rows],
            "members": [dict(row) for row in members_rows],
            "summary": {"pending": int(pending), "active_vip": int(active), "total_requests": int(total_requests)},
        }


def register_vip_routes(app, limiter, base_dir: str, site_user_resolver=None, admin_session_resolver=None):
    database_path = os.path.join(base_dir, "vip.db")
    store = VipStore(database_path)

    def visitor_id():
        value = session.get("nyanko_vip_visitor_id")
        if not isinstance(value, str) or not VISITOR_ID_RE.fullmatch(value):
            value = secrets.token_hex(16)
            session["nyanko_vip_visitor_id"] = value
        session.permanent = True
        return value

    def csrf_token():
        token = session.get("nyanko_vip_csrf")
        if not isinstance(token, str) or len(token) < 32:
            token = secrets.token_urlsafe(32)
            session["nyanko_vip_csrf"] = token
        return token

    def csrf_ok():
        expected = session.get("nyanko_vip_csrf", "")
        supplied = request.headers.get("X-CSRF-Token", "")
        return bool(expected and supplied and hmac.compare_digest(str(expected), str(supplied)))

    def admin_logged_in():
        logged_at = session.get("nyanko_vip_admin_at")
        if not session.get("nyanko_vip_admin") or not isinstance(logged_at, (int, float)):
            return False
        if time.time() - float(logged_at) > 12 * 3600:
            session.pop("nyanko_vip_admin", None)
            session.pop("nyanko_vip_admin_at", None)
            return False
        return True

    def admin_required(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if not admin_logged_in():
                return jsonify({"error": "管理者としてログインしてください。"}), 401
            if not csrf_ok():
                return jsonify({"error": "CSRFトークンが無効です。画面を再読み込みしてください。"}), 403
            return view(*args, **kwargs)
        return wrapped

    def no_store(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["Pragma"] = "no-cache"
        return response

    @app.get("/api/vip/status")
    @limiter.limit("60 per minute")
    def api_vip_status():
        uid = visitor_id()
        member = store.member(uid)
        requests_list = store.user_requests(uid)
        site_user = None
        try:
            site_user = site_user_resolver() if callable(site_user_resolver) else None
        except Exception:
            site_user = None
        account_vip = bool(site_user and site_user.get("is_vip"))
        account_expiry = site_user.get("vip_expires_at") if account_vip else None
        legacy_vip = bool(member and member["is_vip"])
        expiry_values = [value for value in (
            member["expires_at"] if legacy_vip and member else None,
            account_expiry,
        ) if value]
        data = {
            "visitor_id": uid,
            "is_vip": bool(legacy_vip or account_vip),
            "expires_at": max(expiry_values) if expiry_values else None,
            "legacy_is_vip": legacy_vip,
            "account_is_vip": account_vip,
            "site_account": bool(site_user),
            "requests": requests_list,
            "plans": store.plans,
            "csrf_token": csrf_token(),
            "is_admin": bool(admin_logged_in() or (callable(admin_session_resolver) and admin_session_resolver())),
        }
        return no_store(jsonify(data))

    @app.post("/api/vip/request")
    @limiter.limit("5 per hour")
    def api_vip_request():
        if not csrf_ok():
            return jsonify({"error": "CSRFトークンが無効です。画面を再読み込みしてください。"}), 403
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "入力内容が不正です。"}), 400
        try:
            days = int(data.get("plan_days", 0))
        except (TypeError, ValueError):
            days = 0
        if days not in ALLOWED_PLANS:
            return jsonify({"error": "プランを選択してください。"}), 400
        display_name = str(data.get("display_name", "")).strip()
        contact = str(data.get("contact", "")).strip()
        message = str(data.get("message", "")).strip()
        if len(display_name) < 1 or len(display_name) > 40:
            return jsonify({"error": "表示名は1〜40文字で入力してください。"}), 400
        if len(contact) > 120 or len(message) > 500:
            return jsonify({"error": "連絡先は120文字以内、メッセージは500文字以内で入力してください。"}), 400
        try:
            request_id, reference = store.create_request(
                visitor_id(),
                {"plan_days": days, "display_name": display_name, "contact": contact, "message": message},
            )
        except sqlite3.Error:
            app.logger.exception("VIP request could not be saved")
            return jsonify({"error": "申請を保存できませんでした。しばらくしてから再度お試しください。"}), 503
        if request_id is None:
            return jsonify({"error": f"対応待ちの申請（受付番号 {reference}）があります。履歴をご確認ください。"}), 409
        return jsonify({"ok": True, "request_id": request_id, "reference_code": reference})

    @app.post("/api/admin/login")
    @limiter.limit("5 per minute")
    def api_admin_login():
        if not csrf_ok():
            return jsonify({"error": "CSRFトークンが無効です。画面を再読み込みしてください。"}), 403
        configured = (os.getenv("ADMIN_PANEL_PASSWORD") or os.getenv("ADMIN_PASSWORD") or "").strip()
        if not configured:
            return jsonify({"error": "ADMIN_PANEL_PASSWORD が未設定です。.env に設定して再起動してください。"}), 503
        data = request.get_json(silent=True)
        password = str((data or {}).get("password", ""))
        if not password or not secrets.compare_digest(password, configured):
            return jsonify({"error": "管理者パスワードが違います。"}), 403
        # Keep the anonymous visitor identity/CSRF token; add only the admin session flag.
        session["nyanko_vip_admin"] = True
        session["nyanko_vip_admin_at"] = time.time()
        session.permanent = True
        return jsonify({"ok": True})

    @app.post("/api/admin/logout")
    @limiter.limit("20 per minute")
    def api_admin_logout():
        if not csrf_ok():
            return jsonify({"error": "CSRFトークンが無効です。"}), 403
        session.pop("nyanko_vip_admin", None)
        session.pop("nyanko_vip_admin_at", None)
        return jsonify({"ok": True})

    @app.get("/api/legacy-vip/admin/state")
    @limiter.limit("30 per minute")
    @admin_required
    def api_admin_vip_state():
        try:
            return no_store(jsonify(store.admin_state()))
        except sqlite3.Error:
            app.logger.exception("VIP admin state could not be loaded")
            return jsonify({"error": "VIP管理情報を読み込めませんでした。"}), 503

    @app.post("/api/admin/vip/requests/<request_id>/decision")
    @limiter.limit("30 per minute")
    @admin_required
    def api_admin_vip_decision(request_id):
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "入力内容が不正です。"}), 400
        status = str(data.get("status", "")).strip()
        if status not in {"approved", "rejected"}:
            return jsonify({"error": "処理内容が不正です。"}), 400
        note = str(data.get("admin_note", "")).strip()
        if len(note) > 500:
            return jsonify({"error": "管理メモは500文字以内です。"}), 400
        try:
            expires_at, error = store.decide_request(
                request_id, status, note, "password-admin"
            )
        except sqlite3.Error:
            app.logger.exception("VIP purchase request update failed")
            return jsonify({"error": "申請を更新できませんでした。"}), 503
        if error == "not_found":
            return jsonify({"error": "申請が見つかりません。"}), 404
        if error == "already_handled":
            return jsonify({"error": "この申請は既に処理されています。"}), 409
        return jsonify({"ok": True, "status": status, "expires_at": expires_at})

    @app.post("/api/legacy-vip/admin/grant")
    @limiter.limit("20 per minute")
    @admin_required
    def api_admin_vip_grant():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "入力内容が不正です。"}), 400
        uid = str(data.get("visitor_id", "")).strip().lower()
        try:
            days = int(data.get("days", 0))
        except (TypeError, ValueError):
            days = 0
        if not VISITOR_ID_RE.fullmatch(uid) or days not in ALLOWED_PLANS:
            return jsonify({"error": "利用IDまたは期間が不正です。"}), 400
        try:
            expires_at = store.manual_grant(uid, days, "password-admin")
        except sqlite3.Error:
            app.logger.exception("Manual VIP grant failed")
            return jsonify({"error": "VIPを付与できませんでした。"}), 503
        return jsonify({"ok": True, "expires_at": expires_at})

    @app.post("/api/legacy-vip/admin/revoke")
    @limiter.limit("20 per minute")
    @admin_required
    def api_admin_vip_revoke():
        data = request.get_json(silent=True)
        uid = str((data or {}).get("visitor_id", "")).strip().lower()
        if not VISITOR_ID_RE.fullmatch(uid):
            return jsonify({"error": "利用IDが不正です。"}), 400
        try:
            changed = store.revoke(uid)
        except sqlite3.Error:
            app.logger.exception("VIP revoke failed")
            return jsonify({"error": "VIPを停止できませんでした。"}), 503
        if not changed:
            return jsonify({"error": "有効なVIP契約が見つかりません。"}), 404
        return jsonify({"ok": True})

    app.config.setdefault("PERMANENT_SESSION_LIFETIME", timedelta(days=30))
    return store
